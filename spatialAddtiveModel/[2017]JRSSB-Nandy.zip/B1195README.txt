Additive model building for spatial regression
S. Nandy, C. Y. Lim and T. Maiti
J. R. Statist. Soc. B, 79 (2017), 779 -- 800


R code for the paper is contained in the file simulation_code.R


Chae Young Lim
Department of Statistics
Seoul National University
Gawnakro
1 Gawnak-gu
Seoul
Korea 08826

E-mail: twinwood@snu.ac.kr


