
rm(list = ls())
### library
# install.packages("devtools",repos="http://cran.r-project.org")
# library(devtools)
# install_github("funstatpackages/BPST")
library('BPST')
library('MGLM') 

#source functions
source('families.R')
source("gsvcm_est.R")
source("fit.gsvcm.R")
source("cv.gsvcm.R")
source("predict.gsvcm.R")
source("test.gsvcm.R")
family=nb_bps()

Crash_data=as.data.frame(read.csv('data/Crash_Florida.csv',header=T))
Tr=as.matrix(read.csv('data/Tr_Florida.csv',header=FALSE))
V=as.matrix(read.csv('data/V_Florida.csv',header=FALSE))
S_pop=as.matrix(read.csv('data/Florida_pop_location.csv',header=T))

d=3
r=1

# load bivariate basis for the population locations.
B0_pop=basis(V,Tr,d,r,S_pop)
Q2=B0_pop$Q2
H=B0_pop$H
nq=dim(Q2)[2]
BQ2_pop=as.matrix(B0_pop$Bi%*%Q2)
Ind_all=B0_pop$Ind
K=B0_pop$K
P=t(Q2)%*%K%*%Q2


# set up for smoothing parameters in the penalty term
lambda_start=0.00001
lambda_end=100
nlambda=10
lambda=exp(seq(log(lambda_start),log(lambda_end),length.out=nlambda))

#########################################
# Response, Covariates, and locations
S = cbind(Crash_data$Lon, Crash_data$Lat)
X = cbind(Crash_data$log.VMT, Crash_data$log.Pop, Crash_data$Rmale, Crash_data$Rhisp, Crash_data$Rold, Crash_data$Runemploy)
X = as.matrix(scale(X, scale = FALSE)) # centrized covariates
y = Crash_data$Offcrsh
X = as.matrix(cbind(1, X))


# Fitting
mfit0 = fit.gsvcm(y, X, S, V, Tr, d, r, lambda, family, off = 0, r.theta = c(1, 3.8), eps.sigma = 0.05)
y = mfit0$y; S = mfit0$S; X = mfit0$X

# predict response
y_hat = predict(mfit0, X, S)
MSE = mean((y-y_hat)^2)
MSE

# Estimated coefficient functions 
BQ2 = mfit0$B%*%mfit0$Q2
mhat = matrix(0,dim(BQ2)[1],ncol(X))
Jn = dim(BQ2)[2]
mhat = mfit0$beta
mhat_all = as.matrix(BQ2_pop %*% mfit0$theta_hat)



######################### 10-fold CV MSPE:
# MSPE = cv.gsvcm(y, X, S, V, Tr, d = d, r = r, lambda,
#                 family, off = 0, r.theta = c(1, 3.8), nfold = 10, eps.sigma = 0.05)
# mean(MSPE)

######################### GQLR test: choose the function to be tested.
# test_iter = 1   
# test.result = test.gsvcm(y, X, S, V, Tr, d, r, lambda,
#                          test_iter = test_iter, family, off = 0, r.theta = c(1, 3.8), nB = 100, eps.sigma = 0.05)
# test.result




# # Plot:
# # choose the estimated surface plot (beta.ind = 1 to 7):
# beta.ind = 1
# 
# library(colorRamps);library(raster)
# 
# SS_pop = S_pop[Ind_all,]
# bb = read.csv("data//florida_boundary.csv", header=TRUE)
# S1b = cbind(min(bb[,1]), max(bb[,1])) 
# S2b = cbind(min(bb[,2]), max(bb[,2])) 
# 
# dist=0.02 
# uu = seq(S1b[1], S1b[2],dist); vv = seq(S2b[1], S2b[2], dist); n1 = length(uu); n2 = length(vv)
# u = rep(uu,n2); v = rep(vv,rep(n1,n2)); uvpop = cbind(u,v)
# 
# Index = match(data.frame(t(SS_pop)),data.frame(t(uvpop)))
# Zpop = matrix(NaN,dim(uvpop)[1],dim(mhat_all)[2]); Zpop[Index,]=mhat_all
# 
# 
# Index = match(data.frame(t(SS_pop)), data.frame(t(uvpop))); Y0 = matrix(rep(NA, n1*n2), ncol = 1)
# Y0[Index] = Zpop[Index,beta.ind]
# index = point.in.polygon(u,v,bb[,1], bb[,2]); Y0[index == 0] = NA
# QT = quantile(Y0[is.na(Y0)==0], probs = seq(0, 1, 0.01))[c(1,2,26,76,100,101)]; int.QT = QT[4]-QT[3]
# if(QT[6] > (QT[4] + 1.5*int.QT)){Y0[Y0 > QT[5]] = QT[5]}
# if(QT[1] < (QT[3]- 1.5*int.QT)){Y0[Y0 < QT[2]]=QT[2]}
# alpha_fitted = data.frame(u,v,Y0); spg = alpha_fitted; coordinates(spg) = ~u + v; gridded(spg) = TRUE; rasterDF = raster(spg)
# colours = colorRamps::matlab.like(100); par(mar = c(1.1, 1.1, 1.1, 1.1))
# 
# # Control Font size
# op = par(cex = 1.4)
# 
# plot(rasterDF, col = colours, axes = FALSE, box = FALSE, legend.width=1, legend.shrink = 0.85)
# points(bb, type = 'l', col = 'black')




