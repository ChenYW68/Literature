##############################################################################
# Project: Generalized Spatially Varying Coefficient Models
##############################################################################
rm(list = ls())

# library
# install.packages("devtools",repos="http://cran.r-project.org")
# library(devtools)
# install_github("funstatpackages/BPST")
library('BPST') # basis matrix
library('mgcv') # horse shoe domain
library('MGLM') # kr function for design matrix
library('MASS') # generate negbinom response

# source functions
source("Datagenerator.R")
source("families.R")
source("gsvcm_est.R")
source("fit.gsvcm.R")
source("cv.gsvcm.R")
source("predict.gsvcm.R")

# Select one of the families as follows:
family=gaussian()
  # family=poisson()
  # family=nb_bps()


# Load matrices for triangles (Tr) and vertices (V)
# Select a pair of triangulations (Tr and V):  
Tr=as.matrix(read.csv('data/Tr0_horse.csv',header=FALSE))
V=as.matrix(read.csv('data/V0_horse.csv',header=FALSE))
  #Tr=as.matrix(read.csv('data/Tr1_horse.csv',header=FALSE))
  #V=as.matrix(read.csv('data/V1_horse.csv',header=FALSE))
  #Tr=as.matrix(read.csv('data/Tr2_horse.csv',header=FALSE))
  #V=as.matrix(read.csv('data/V2_horse.csv',header=FALSE))


# Setup for simulation
n = 1000    # number of sample points / n=1000, n = 2000, n = 50,000 (simulation results)
nsim = 100  # number of iterations / nsim=100
d = 2       # degree / d = 2 or d = 3
r = 1       # smoothness / r = 1


# Generate population data
ngrid = 0.005                                     # distance between grid points 
all_pop = as.matrix(Datagenerator(family, ngrid)) # warnings() for NAs


# This contains population data only on the target domain.
pop.r=all_pop[!is.na(all_pop[,'m1']),]
N=nrow(pop.r)

# load bivariate basis for the population locations.
S_pop=all_pop[,6:7]
B0_pop=basis(V,Tr,d,r,S_pop)
Q2=B0_pop$Q2
nq=dim(Q2)[2]
BQ2_pop=as.matrix(B0_pop$Bi%*%Q2)
Ind_all=B0_pop$Ind
K=B0_pop$K
P=t(Q2)%*%K%*%Q2

beta_pop=all_pop[Ind_all,2:3]
X_pop=all_pop[Ind_all,4:5]
y_pop=all_pop[Ind_all,1]

# set up for smoothing parameters in the penalty term
lambda_start=0.0001
lambda_end=10
nlambda=10
lambda=exp(seq(log(lambda_start),log(lambda_end),length.out=nlambda))

# Initials for MISE for bivaraite functions, MSPE for Y, and running time.
MISE_Beta1_all=c()
MISE_Beta2_all=c()
MSE_y_all=c()
MSPE_y_all=c()
time_all=c()
time2_all=c()

# to save estimated betas
mhat_all_all=c()


for(iter in 1:nsim){
	time.start=proc.time()
	print(iter)
  set.seed(iter)
  ind.s=sample(N,n,replace=FALSE)
  data=as.matrix(pop.r[ind.s,])

  y=data[,1]
  beta0=data[,c(2:3)]
  X=data[,c(4:5)]
  S=data[,c(6:7)]
  
  # fit the data: one can choose method = "GSVCM" or "GSVCMQR"
  mfit0 = fit.gsvcm(y, X, S, V, Tr, d, r, lambda, family, off = 0, r.theta = c(4, 8),  
                    method = "GSVCM")
  y = mfit0$y; S = mfit0$S; X = mfit0$X
  y_hat = predict(mfit0, X, S)
  
  
  # Predicted beta0 and beta1
  mhat = mfit0$beta
  mhat_all = cbind(BQ2_pop%*%mfit0$theta_hat[,1], BQ2_pop%*%mfit0$theta_hat[,2])

  # MISE for beta0 and beta1 
  MISE_Beta1 = (ngrid*ngrid)*sum((mhat_all[,1] - beta_pop[,1])^2,na.rm=TRUE)
  MISE_Beta2 = (ngrid*ngrid)*sum((mhat_all[,2] - beta_pop[,2])^2,na.rm=TRUE)

  # MSE for response
  MSE_y = mean((y-y_hat)^2, na.rm=TRUE)
  time.end = proc.time()
  time = (time.end-time.start)[3] # measure running time for estimation
  
  # k-fold cross-validation: one can choose method = "GSVCM" or "GSVCMQR"
  time.start = proc.time()
  MSPE = cv.gsvcm(y, X, S, V, Tr, d = d, r = r, lambda, family, off = 0,  r.theta = c(4, 8), nfold = 10, 
                  method = "GSVCM")
  MSPE_y = mean(MSPE)
  time.end = proc.time()  
  time2 = (time.end-time.start)[3] # measure running time for 10-fold cv MSPE
  
  MISE_Beta1_all = cbind(MISE_Beta1_all,MISE_Beta1)
  MISE_Beta2_all = cbind(MISE_Beta2_all,MISE_Beta2)
  MSE_y_all = cbind(MSE_y_all, MSE_y)
  MSPE_y_all = cbind(MSPE_y_all, MSPE_y)
  time_all = cbind(time_all,time)
  time2_all = cbind(time2_all,time2)
  mhat_all_all = cbind(mhat_all_all,mhat_all)
    
  cat('MISE for beta 1:', MISE_Beta1, 'MISE for beta 2:', MISE_Beta2, '\n')
  cat('Time:', time,'\n')
}


# The result of simulation
result = cbind(mean(MISE_Beta1_all), mean(MISE_Beta2_all),mean(MSE_y_all), mean(MSPE_y_all), mean(time_all), mean(time2_all))
colnames(result) = c('MISE_Beta1', 'MISE_Beta2', 'MSE_y', 'MSPE_y', 'time_MSE_y', 'time_MSPE_y')
result



### rm(list=setdiff(ls(), c("result","beta_pop", "mhat_all","S_pop", "all_pop", "Ind_all")))
#######################################################################
# # Only for the plots
# library(plot3D)
# beta01_last=mhat_all
# u=unique(S_pop[,1]);v=unique(S_pop[,2]);n1=length(u); n2=length(v)
 
## true surfaces of beta0 and beta1
# image2D(u,v,z=matrix(all_pop[,'m1'],n1,n2), col = heat.colors(5))
# contour(u,v,matrix(all_pop[,'m1'],n1,n2), add = TRUE, drawlabels = TRUE)
# image2D(u,v,z=matrix(all_pop[,'m2'],n1,n2),  col = heat.colors(5))
# contour(u,v,matrix(all_pop[,'m2'],n1,n2), add = TRUE, drawlabels = TRUE)

## estimated surfaces of beta0 and beta1
# beta.r1.all=matrix(NA,n1*n2,1)
# beta.r1.all[Ind_all,]=beta01_last[,1]
# beta.r1.mtx=matrix(beta.r1.all,n1,n2)
# image2D(u,v,z=matrix(beta.r1.mtx,n1,n2), col = heat.colors(5))
# contour(u,v,beta.r1.mtx, add = TRUE, drawlabels = TRUE)
 
# beta.r2.all=matrix(NA,n1*n2,1)
# beta.r2.all[Ind_all,]=beta01_last[,2]
# beta.r2.mtx=matrix(beta.r2.all,n1,n2)
# image2D(u,v,z=matrix(beta.r2.mtx,n1,n2), col = heat.colors(5))
# contour(u,v,beta.r2.mtx, add = TRUE, drawlabels = TRUE)
#######################################################################
